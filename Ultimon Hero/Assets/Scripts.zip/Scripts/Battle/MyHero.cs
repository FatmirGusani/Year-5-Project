﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyHero : MonoBehaviour
{

    public string Name = "Char";
    public Sprite Image;
    public int Level = 5;
    public int HP = 100;
    public int AttackPower = 45;
    public string type = "Fire";



    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
