﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EneHero : MonoBehaviour
{
    public string Name = "Test";
    public Sprite Image;
    public int Level = 1;
    public int HP = 100;
    public int AttackPower = 15;
    public string type = "Electric";


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
